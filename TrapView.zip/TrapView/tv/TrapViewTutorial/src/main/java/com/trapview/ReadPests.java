package com.trapview;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.trapview.entity.Sm_pests;

public class ReadPests {
	static List<Sm_pests> pest_list= new ArrayList<Sm_pests>();
	public static void main(String[] args) { //main sluzi samo da printam lokalno
		getPests();
	}
	public static List<Sm_pests> getPests(){

		//create session factory; configure default arg
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		
		//create session
		Session session = factory.getCurrentSession();
		
		try {			
			
			//start a transaction
			session.beginTransaction(); 
			
			pest_list= session.createQuery("from Sm_pests p order by p.id").getResultList(); 
			
			for (Sm_pests currentPest : pest_list) {
				System.out.println(currentPest);}
			
			//commit the transaction
			session.getTransaction().commit();
			
		}
		finally {
			//System.out.print("here");
			factory.close();
		}
		return pest_list;
	}

}
