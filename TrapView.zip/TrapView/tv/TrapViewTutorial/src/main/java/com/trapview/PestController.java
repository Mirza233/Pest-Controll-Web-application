package com.trapview;

import com.trapview.entity.Sm_pests;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.faces.application.FacesMessage;

import javax.faces.context.FacesContext;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.jboss.logging.Logger;

@Named
@SessionScoped
public class PestController {
	private List<Sm_pests> pests;
	private ReadPests read;
	private Logger logger = Logger.getLogger(getClass().getName());
	
	public PestController() throws Exception {
		pests = new ArrayList<Sm_pests>();
		//read = ReadPests.getPests();
		
	}
	
	public List<Sm_pests> getPests(){
		return pests;
	}
	
	public void loadPests() { //retrieve information from DB; 
		logger.info("Loading data");
		pests.clear();
		try {
			pests = ReadPests.getPests();
		}
		catch (Exception exc){
			
			addErrorMessage(exc);
		}
	}
	
	private void addErrorMessage(Exception exc) {
		FacesMessage message = new FacesMessage("Error: "+ exc.getMessage());
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
}
