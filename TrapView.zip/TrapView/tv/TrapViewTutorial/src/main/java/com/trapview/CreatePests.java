package com.trapview;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.trapview.entity.Sm_pests;

public class CreatePests {

	public static void main(String[] args) {

		//create session factory; configure default arg
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		
		//create session
		Session session = factory.getCurrentSession();
		
		try {
			//use the session object to save Java Object
			
			//Create sm_pests obj

			Sm_pests pest = new Sm_pests(521,"Mirza","Mir");
			
			
			//start a transaction
			session.beginTransaction(); 
			
			//save the obj 
			session.save(pest);
			
			//commit the transaction
			session.getTransaction().commit();
			
		}
		finally {
			//System.out.print("here");
			factory.close();
		}
	}

}
