package com.trapview.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import java.time.LocalDateTime;


@Entity
@Table(name = "sm.sm_pests")

public class Sm_pests {
	

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "id_pest")
	//public
	Integer id_pest;
	

	
	@Column(name = "latin_name")
	String latin_name;
	
	@Column(name = "ref_link")
	String link;
	
	@Column(name = "code")
	String code_char;
	
	@Column(name = "d_insert")
	private LocalDateTime date = LocalDateTime.now();
	
	@Column(name = "id_inserter")
	Integer id_ins;
	
	
	//@Column(name = "d_update")
	//String dateupd;
	
	@Column(name = "id_updater")
	Integer id_upd;
	
	@Column(name = "activity")
	String activity = "1";
	
//	@Column (name = "img")
	//String img;
	
	@Column (name = "valid_to")
	LocalDateTime vt;
	
	@Column (name = "id_session")
	Integer id_sess = 0;
	
	@Column (name = "notes")
	String notes = null;
	/*
	@Column (name = "hide_score")
	double hide_score; // value (0,1)
	*/
	@Column (name = "img_recognition")
	Integer img_rec = 0;
	
	@Column (name = "alarm_threshold_up")
	double alarm_up = 0.1; //value(0,1)
	
	@Column (name = "alarm_threshold_low")
	double alarm_low = 0.1; //0,1
	
	/*nulls
	@Column (name = "recognition_model")
	String recognition_model = null; 
	
	@Column (name = "stroke_width")
	  String stroke_width = null;
	  @Column (name = "no_pests_alert_low")
	  String no_pests_alert_low =null;
	  @Column (name = "no_pests_alert_up")
	  String no_pests_alert_up = null;
	  @Column (name = "no_pests_auto_scm")
	  String no_pests_auto_scm = null;
	*/
	
	
	//Constructor
	public Sm_pests() {
		
	}
	public Sm_pests(Integer id, String latin_name, String code_char) {
		super();
		this.id_pest = id;
		this.latin_name = latin_name;
		this.link = null;
		this.code_char = code_char;
		//this.dateupd = null;
		this.id_ins = 0;
		this.id_upd = 0;

	}
	
	
	
	//getters,setters 
	
	public Integer getId_pest() {
		return id_pest;
	}
	public String getLink() {
		return link;
	}



	public void setLink(String link) {
		this.link = link;
	}



	public LocalDateTime getDate() {
		return date;
	}


	public Integer getId_ins() {
		return id_ins;
	}



	public void setId_ins(Integer id_ins) {
		this.id_ins = id_ins;
	}


/*
	public String getDateupd() {
		return dateupd;
	}



	public void setDateupd(String dateupd) {
		this.dateupd = dateupd;
	}
*/


	public Integer getId_upd() {
		return id_upd;
	}


/*
	public void setId_upd(Integer id_upd) {
		this.id_upd = id_upd;
	}
*/


	public void setId_pest(Integer id_pest) {
		this.id_pest = id_pest;
	}



	public String getActivity() {
		return activity;
	}



	public void setActivity(String activity) {
		this.activity = activity;
	}


/*
	public String getImg() {
		return img;
	}



	public void setImg(String img) {
		this.img = img;
	}



	public String getVt() {
		return vt;
	}



	public void setVt(String vt) {
		this.vt = vt;
	}*/



	public Integer getId_sess() {
		return id_sess;
	}



	public void setId_sess(Integer id_sess) {
		this.id_sess = id_sess;
	}



	public String getNotes() {
		return notes;
	}



	public void setNotes(String notes) {
		this.notes = notes;
	}

/*

	public double getHide_score() { //NUMERIC!!!!
		return hide_score;
	}



	public void setHide_score(double hide_score) {
		this.hide_score = hide_score;
	}
*/


	public Integer getImg_rec() {
		return img_rec;
	}



	public void setImg_rec(Integer img_rec) {
		this.img_rec = img_rec;
	}



	public double getAlarm_up() {
		return alarm_up;
	}



	public void setAlarm_up(double alarm_up) {
		this.alarm_up = alarm_up;
	}



	public double getAlarm_low() {
		return alarm_low;
	}



	public void setAlarm_low(double alarm_low) {
		this.alarm_low = alarm_low;
	}


/*
	public String getRecognition_model() {
		return recognition_model;
	}



	public void setRecognition_model(String recognition_model) {
		this.recognition_model = recognition_model;
	}



	public String getStroke_width() {
		return stroke_width;
	}



	public void setStroke_width(String stroke_width) {
		this.stroke_width = stroke_width;
	}



	public String getNo_pests_alert_low() {
		return no_pests_alert_low;
	}



	public void setNo_pests_alert_low(String no_pests_alert_low) {
		this.no_pests_alert_low = no_pests_alert_low;
	}



	public String getNo_pests_alert_up() {
		return no_pests_alert_up;
	}



	public void setNo_pests_alert_up(String no_pests_alert_up) {
		this.no_pests_alert_up = no_pests_alert_up;
	}



	public String getNo_pests_auto_scm() {
		return no_pests_auto_scm;
	}



	public void setNo_pests_auto_scm(String no_pests_auto_scm) {
		this.no_pests_auto_scm = no_pests_auto_scm;
	}

*/


	public String getLatin_name() {
		return latin_name;
	}
	public void setLatin_name(String latin_name) {
		this.latin_name = latin_name;
	}
	public String getCode_char() {
		return code_char;
	}
	public void setCode_char(String code_char) {
		this.code_char = code_char;
	}


	//Create toString so we can display the data for debugging purposes
	@Override
	public String toString() {
		return "Sm_pests [id=" +  id_pest + ", latin_name=" + latin_name + ", code_char=" + code_char + "]";
	}
	
	
	
}
