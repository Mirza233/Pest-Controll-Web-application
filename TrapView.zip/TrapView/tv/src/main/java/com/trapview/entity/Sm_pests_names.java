package com.trapview.entity;

import java.time.LocalDateTime;

import javax.faces.bean.ManagedBean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.trapview.ReadPests;


@Entity
@Table(name = "sm.sm_pests_names")

@ManagedBean(name = "b_name")
public class Sm_pests_names {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "id_pest")
	//public
	Integer id_pest_name;
	
	
	@ManyToOne
    @JoinColumn(name = "id_pest")
	private Sm_pests id_pest;
	
	@ManyToOne
    @JoinColumn(name = "id_language")
	private Sm_languages id_language;
	
	@Column(name = "name")
	String name;
	
	@Column(name = "d_insert")
	private LocalDateTime date=LocalDateTime.now();
	
	@Column(name = "id_inserter")
	Integer id_inserter = 0;
	
	@Column(name = "d_update")
	LocalDateTime d_update=LocalDateTime.now();
	
	@Column(name = "id_updater")
	Integer id_updater;
	
	@Column(name = "activity")
	Integer activity= 1;
	
	@Column(name = "valid_to")
	LocalDateTime valid_to;
	
	@Column(name = "id_session")
	Integer id_session = 0;
	
	@Column(name = "notes")
	String notes;

	
	
	
	//FOR DEBUGGING IN READ CLASS
	@Override
	public String toString() {
		return "Sm_pests [id=" +  id_pest_name + ", name=" + name + ", language no=" + id_language + "]";
	}
	
	
	
	//getters;setters
	public Integer getId_pest_name() {
		return id_pest_name;
	}

	public void setId_pest_name(Integer id_pest_name) {
		this.id_pest_name = id_pest_name;
	}

	public Sm_pests getId_pest() {
		return id_pest;
	}

	public void setId_pest(Sm_pests id) {
		id_pest = id;
	}

	public Sm_languages getId_language() {
		return id_language;
	}

	public void setId_language(Sm_languages id_language) {
		this.id_language = id_language;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate() {
		this.date = LocalDateTime.now();
	}
	public Integer getId_inserter() {
		return id_inserter;
	}

	public void setId_inserter(Integer id_inserter) {
		this.id_inserter = id_inserter;
	}

	public LocalDateTime getD_update() {
		return d_update;
	}

	public void setD_update(LocalDateTime d_update) {
		this.d_update = d_update;
	}

	public Integer getId_updater() {
		return id_updater;
	}

	public void setId_updater(Integer id_updater) {
		this.id_updater = id_updater;
	}

	public Integer getActivity() {
		return activity;
	}

	public void setActivity(Integer activity) {
		this.activity = activity;
	}

	public LocalDateTime getValid_to() {
		return valid_to;
	}

	public void setValid_to() {
		this.valid_to = LocalDateTime.now();
	}

	public Integer getId_session() {
		return id_session;
	}

	public void setId_session(Integer id_session) {
		this.id_session = id_session;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Sm_pests_names(String name) {
		this.activity = 1;
		this.name = name;
	}
	public Sm_pests_names(){
		
	}
}
