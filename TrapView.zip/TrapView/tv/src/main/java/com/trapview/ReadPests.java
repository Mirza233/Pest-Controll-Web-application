package com.trapview;


import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.trapview.entity.Sm_languages;
import com.trapview.entity.Sm_pests;
import com.trapview.entity.Sm_pests_names;
public class ReadPests {
	static List<Sm_pests> pest_list= new ArrayList<Sm_pests>();
	static List<Sm_pests_names> pest_names_list= new ArrayList<Sm_pests_names>();
	static List<Sm_languages> languages= new ArrayList<Sm_languages>();


	
	public static void main(String[] args) { //I created main to be able to print the lists locally
		//getPests();
		//getPestsNames();
		return;
	}
	
	
	public static List<Sm_pests> getPests(){

		//create session factory; configure default arg
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		
		//create session
		Session session = factory.getCurrentSession();
		
		try {			
			
			//start a transaction
			session.beginTransaction(); 
			
			pest_list= session.createQuery("from Sm_pests p where p.activity='1' order by p.id").getResultList(); 
			//for (Sm_pests currentPest : pest_list) { //debugging purposes
				//break;
				//System.out.println(currentPest);
				//}
			
			//commit the transaction
			session.getTransaction().commit();
			
		}
		finally {

			factory.close();
		}
		return pest_list;
	}
	
	public static List<Sm_pests_names> getPestsNames(){
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests_names.class).buildSessionFactory();
		Session session = factory.getCurrentSession();

		try {			
					
					//start a transaction
					session.beginTransaction(); 
					
					pest_names_list= session.createQuery("from Sm_pests_names p where p.activity='1' order by p.id").getResultList(); 
					for (Sm_pests_names currentPest : pest_names_list) { //debugging purposes
						break;
						//System.out.println(currentPest);
						
						}
					
					//commit the transaction
					session.getTransaction().commit();
					
				}
		finally {
			//System.out.print("here");
			factory.close();
		}
		return pest_names_list;
	}
	
	
	
	public static List<Sm_languages> getLanguages(){

		//create session factory; configure default arg
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		
		//create session
		Session session = factory.getCurrentSession();
		
		try {			
			
			//start a transaction
			session.beginTransaction(); 
			
			languages= session.createQuery("from Sm_languages").getResultList(); 
			//for (Sm_pests currentPest : pest_list) { //debugging purposes
				//break;
				//System.out.println(currentPest);
				//}
			
			//commit the transaction
			session.getTransaction().commit();
			
		}
		finally {

			factory.close();
		}
		return languages;
	}

}
