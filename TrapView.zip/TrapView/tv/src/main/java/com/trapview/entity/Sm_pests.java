package com.trapview.entity;



import javax.faces.bean.ManagedBean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "sm.sm_pests")

@ManagedBean(name = "b")
public class Sm_pests {
	

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "id_pest")
	//public
	Integer id_pest;
	

	
	@Column(name = "latin_name")
	String latin_name;
	
	@Column(name = "ref_link")
	String link;
	
	@Column(name = "code")
	String code_char;
	
	//@Column (name = "img")
	//String img;
	
	@Column(name = "d_insert")
	private LocalDateTime date = LocalDateTime.now();
	
	@Column(name = "id_inserter")
	Integer id_ins;
	
	
	@Column(name = "d_update")
	private LocalDateTime dateupd = LocalDateTime.now();
	
	@Column(name = "id_updater")
	Integer id_upd;
	
	@Column(name = "activity")
	String activity;
	
	
	@Column (name = "valid_to")
	LocalDateTime vt;
	
	@Column (name = "id_session")
	Integer id_sess = 0;
	
	@Column (name = "notes")
	String notes;
	
	@Column (name = "hide_score")
	Double hide_score; // value (0,1)
	
	@Column (name = "img_recognition")
	Integer img_rec = 0;
	
	@Column (name = "alarm_threshold_up")
	Double alarm_up = 0.1; //value(0,1)
	
	@Column (name = "alarm_threshold_low")
	Double alarm_low = 0.1; //0,1
	
	
	@Column (name = "recognition_model")
	Integer recognition_model; 
	
	

	
	
	
	@Column (name = "stroke_width")
	  Integer stroke_width;
	
	  @Column (name = "no_pests_alert_low")
	  Integer no_pests_alert_low ;
	  @Column (name = "no_pests_alert_up")
	  Integer no_pests_alert_up ;
	  @Column (name = "no_pests_auto_scm")
	  Integer no_pests_auto_scm ;
	
	
	//Constructors
	public Sm_pests() {
		this.id_ins = 0;
		this.id_upd = 0;
		this.activity = "1";
	}
	public Sm_pests(Integer id) {
		super();
		this.id_pest = id;
		
		this.latin_name = " ";
		this.code_char = " ";
		
		//this.dateupd = null;
		this.id_ins = 0;
		this.id_upd = 0;
		this.activity = "1";

	}
	
	
	
	


	/*Create toString so we can display the data for debugging purposes
	@Override
	public String toString() {
		return "Sm_pests [id=" +  id_pest + ", latin_name=" + latin_name + ", code_char=" + code_char + "]";
	}*/
	@Override
	public String toString() {
		return id_pest+" "+latin_name;
		}
	//getters,setters 
	public Integer getId_pest() {
		return id_pest;
	}
	public void setId_pest(Integer id_pest) {
		this.id_pest = id_pest;
	}
	public String getLatin_name() {
		return latin_name;
	}
	public void setLatin_name(String latin_name) {
		this.latin_name = latin_name;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getCode_char() {
		return code_char;
	}
	public void setCode_char(String code_char) {
		this.code_char = code_char;
	}
	//public String getImg() {
		//return img;
	//}
	//public void setImg(String img) {
	//	this.img = img;
//	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public Integer getId_ins() {
		return id_ins;
	}
	public void setId_ins(Integer id_ins) {
		this.id_ins = id_ins;
	}
	public LocalDateTime getDateupd() {
		return dateupd;
	}
	public void setDateupd(LocalDateTime dateupd) {
		this.dateupd = dateupd;
	}
	public Integer getId_upd() {
		return id_upd;
	}
	public void setId_upd(Integer id_upd) {
		this.id_upd = id_upd;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public LocalDateTime getVt() {
		return vt;
	}
	public void setVt(LocalDateTime vt) {
		this.vt = vt;
	}
	public Integer getId_sess() {
		return id_sess;
	}
	public void setId_sess(Integer id_sess) {
		this.id_sess = id_sess;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	public Double getHide_score() {
		return hide_score;
	}
	public void setHide_score(Double hide_score) {
		this.hide_score = hide_score;
	}
	public Integer getImg_rec() {
		return img_rec;
	}
	public void setImg_rec(Integer img_rec) {
		this.img_rec = img_rec;
	}
	public Double getAlarm_up() {
		return alarm_up;
	}
	public void setAlarm_up(Double alarm_up) {
		this.alarm_up = alarm_up;
	}
	public Double getAlarm_low() {
		return alarm_low;
	}
	public void setAlarm_low(Double alarm_low) {
		this.alarm_low = alarm_low;
	}
	public Integer getRecognition_model() {
		return recognition_model;
	}
	public void setRecognition_model(Integer recognition_model) {
		this.recognition_model = recognition_model;
	}
	public Integer getStroke_width() {
		return stroke_width;
	}
	public void setStroke_width(Integer stroke_width) {
		this.stroke_width = stroke_width;
	}
	public Integer getNo_pests_alert_low() {
		return no_pests_alert_low;
	}
	public void setNo_pests_alert_low(Integer no_pests_alert_low) {
		this.no_pests_alert_low = no_pests_alert_low;
	}
	public Integer getNo_pests_alert_up() {
		return no_pests_alert_up;
	}
	public void setNo_pests_alert_up(Integer no_pests_alert_up) {
		this.no_pests_alert_up = no_pests_alert_up;
	}
	public Integer getNo_pests_auto_scm() {
		return no_pests_auto_scm;
	}
	public void setNo_pests_auto_scm(Integer no_pests_auto_scm) {
		this.no_pests_auto_scm = no_pests_auto_scm;
	}
	
	
	
}
