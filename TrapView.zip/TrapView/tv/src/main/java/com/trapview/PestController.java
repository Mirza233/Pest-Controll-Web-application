package com.trapview;


//TODO:
// * modify master
// * modify detail


import com.trapview.entity.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.GeneratedValue;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.jboss.logging.Logger;

@ManagedBean(name = "bean")

public class PestController{
	Integer intid;
	String strlang;
	String strname;
	
	public Integer getIntid() {
		return intid;
	}



	public void setIntid(Integer intid) {
		this.intid = intid;
	}



	public String getStrlang() {
		return strlang;
	}



	public void setStrlang(String strlang) {
		this.strlang = strlang;
	}



	public String getStrname() {
		return strname;
	}



	public void setStrname(String strname) {
		this.strname = strname;
	}



	public void setPests(List<Sm_pests> pests) {
		this.pests = pests;
	}



	public void setPest_names(List<Sm_pests_names> pest_names) {
		this.pest_names = pest_names;
	}



	public void setLanguages(List<Sm_languages> languages) {
		this.languages = languages;
	}



	//Debugging purpose
	public static void main(String[]args) {
		return;
		//Sm_pests_names pest= new Sm_pests_names("MR"); 
		//add_pest_name(0,1,pest);
	}//
	private List<Sm_pests> pests;
	private List<Sm_pests_names> pest_names;
	private List <Sm_languages> languages;
	//private Logger logger = Logger.getLogger(getClass().getName());

	
	public List<Sm_languages> getLanguages() {

		this.languages = ReadPests.getLanguages();
		return this.languages;
	}



	public PestController() throws Exception {
		pests = new ArrayList<Sm_pests>();
		pest_names = new ArrayList<Sm_pests_names>();
		
	}
	
	public List<Sm_pests> getPests(){
		loadPests();
		return this.pests;
	}
	
	public List<Sm_pests_names> getPest_names(){
		loadPest_names();
		return this.pest_names;
	}
	
	public void loadPests() { //retrieve information from DB; 
		//logger.info("Loading data");
		pests.clear();
		try {
			pests = ReadPests.getPests(); //Method returns the list of data from the DB
		}
		catch (Exception exc){
			addErrorMessage(exc);
			
		}
	}
	
	public void loadPest_names() { //retrieve information from DB; 
		//logger.info("Loading data");
		pests.clear();
		try {
			pest_names = ReadPests.getPestsNames(); //Method returns the list of data from Details table of the DB
			
		}
		catch (Exception exc){
			addErrorMessage(exc);
			
		}
	}
	public static void add(Sm_pests newpest) {
		//create session factory; configure default arg
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		
		//create session
		Session session = factory.getCurrentSession();
		
		try {			
			//start a transaction
			session.beginTransaction(); 
			
			//Create sm_pests obj with id generated below
			List<Sm_pests> max_id_instance = session.createQuery("from Sm_pests order by id desc").setMaxResults(1).getResultList();
			int max_id = max_id_instance.get(0).getId_pest(); // @GeneratedValue doesn't automatically generate id.
			
			Sm_pests pest = newpest;
			pest.setId_pest(max_id+1);

			session.save(pest);
			
			session.getTransaction().commit();
			
		}
		finally {
			factory.close();
		}
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "index.xhtml");

	}
	
	public static void deactivate(Sm_pests pest) {
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction(); 
		session.evict(pest);
		pest.setActivity("0");
		pest.setVt(LocalDateTime.now());
		session.update(pest);
		int a = pest.getId_pest();

		
		session.getTransaction().commit();
		factory.close();
		deactivate(a);
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "index.xhtml");
		
	}
	
	public static void deactivate(int a) {
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		List <Sm_pests_names> deac = session.createQuery("from Sm_pests_names p where p.id_pest.id_pest= "+a).getResultList();
		
		

		for (Sm_pests_names i:deac){
			session.evict(i);
			i.setActivity(0);
			i.setValid_to();
			session.update(i);
		}
		session.getTransaction().commit();
		factory.close();
	}
	
	public static void add_pest_name(Integer pest_id,int lang,Sm_pests_names pest) {

		
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		
		try {			
			//start a transaction
			session.beginTransaction(); 
			
			//Create sm_pests_name obj with id generated below
			List<Sm_pests_names> max_id_instance = session.createQuery("from Sm_pests_names order by id desc").setMaxResults(1).getResultList();
			Integer max_id = max_id_instance.get(0).getId_pest_name(); // Same problem as above with @GeneratedValue
			
			//Sm_pests_names pest = new Sm_pests_names(name);

			pest.setId_pest_name(max_id+1);
			
			pest.setId_language((Sm_languages) session.load(Sm_languages.class, lang));	
			
			pest.setId_pest(session.load(Sm_pests.class, pest_id));
			
			session.save(pest);
			
			session.getTransaction().commit();
			
		}finally {
			factory.close();
		}
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "names.xhtml");

		
	 }
	
	private void addErrorMessage(Exception exc) {
		FacesMessage message = new FacesMessage("Error: "+ exc.getMessage());
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public void load(String id_pest) {
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.openSession();
		try {

			session.beginTransaction(); 

			List<Sm_pests> list= session.createQuery("from Sm_pests p where p.activity='1' and p.id_pest="+id_pest).getResultList();
			Sm_pests pest = list.get(0);
			ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();		
			
			Map<String, Object> requestMap = externalContext.getRequestMap();
			requestMap.put("b", pest);
			
		} finally {
			session.close();
		}
				
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "updatemaster.xhtml");

	}
	
	public void load1(Integer id_name) {
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.openSession();
		try {

			session.beginTransaction(); 

			List<Sm_pests_names> list= session.createQuery("from Sm_pests_names p where p.id_pest_name="+id_name).getResultList();
			Sm_pests_names pest = list.get(0);
			ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();		
			
			Map<String, Object> requestMap = externalContext.getRequestMap();
			requestMap.put("b_name", pest);
			
		} finally {
			session.close();
		}
				
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "updatedetail.xhtml");

	}
	
	public void update(Integer id_pest,String name,String code,String link,Double score) {
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		
		session.beginTransaction();
		
		List<Sm_pests> list= session.createQuery("from Sm_pests p where p.id_pest="+id_pest).getResultList();
		Sm_pests pest = list.get(0);
		
		 
		session.evict(pest);
		pest.setLatin_name(name);
		pest.setCode_char(code);
		pest.setLink(link);
		pest.setHide_score(score);
		pest.setDateupd(LocalDateTime.now());
		session.update(pest);

		session.getTransaction().commit();
		factory.close();

		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "index.xhtml");
		
	}
	
	public void updatedetail(Integer id_pest_name,String name) {
		SessionFactory factory = 
				new Configuration().configure().
				addAnnotatedClass(Sm_pests.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		
		session.beginTransaction();
		
		List<Sm_pests_names> list= session.createQuery("from Sm_pests_names p where p.id_pest_name="+id_pest_name).getResultList();
		Sm_pests_names pest = list.get(0);
		
		 
		session.evict(pest);
		pest.setName(name);
		pest.setD_update(LocalDateTime.now());
		session.update(pest);

		session.getTransaction().commit();
		factory.close();

		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation(FacesContext.getCurrentInstance(), null, "names.xhtml");
		
	}
	
}
