package com.trapview.entity;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.faces.bean.ManagedBean;
import javax.persistence.Column;

import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import java.time.LocalDateTime;



@Entity
@Table(name = "sm.sm_languages")


@ManagedBean(name = "b_lang")
public class Sm_languages {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "id_pest")
	//public
	Integer id_language;

	
	@Column(name = "name")
	String name;
	
	@Column(name = "d_insert")
	private LocalDateTime date = LocalDateTime.now();
	
	@Column(name = "id_inserter")
	Integer id_ins;
	
	@Column(name = "activity")
	Integer active;
	
	@Column(name = "id_session")
	Integer id_session;
	
	@Column(name = "d_update")
	private LocalDateTime upd_date = LocalDateTime.now();
	
	@Column(name = "id_updater")
	Integer id_upd;
	
	@Column(name = "notes")
	private String notes;
	
	@Column(name = "iso_code")
	private String iso_code;
	
	@Column(name = "order_seq")
	private String order_seq;

	public Integer getId_language() {
		return id_language;
	}

	public String getName() {
		return name;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public Integer getId_ins() {
		return id_ins;
	}

	public Integer getActive() {
		return active;
	}

	public Integer getId_session() {
		return id_session;
	}

	public LocalDateTime getUpd_date() {
		return upd_date;
	}

	public Integer getId_upd() {
		return id_upd;
	}

	public String getNotes() {
		return notes;
	}

	public String getIso_code() {
		return iso_code;
	}

	public String getOrder_seq() {
		return order_seq;
	}
	
	public String toString() {
		return ""+ name;
		}
	
	
	
	
}

